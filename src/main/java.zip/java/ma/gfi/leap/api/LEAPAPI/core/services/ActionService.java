package ma.gfi.leap.api.LEAPAPI.core.services;


import ma.gfi.leap.api.LEAPAPI.core.dao.models.Action;
import ma.gfi.leap.api.LEAPAPI.core.dao.models.Risque;
import ma.gfi.leap.api.LEAPAPI.core.dao.repositories.ActionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;

@Service
public class ActionService implements IActionService {

    @Autowired
    private ActionRepository ActionRepository;

    @Override
    public Collection<Action> getAllActions() {
        Collection<Action> list = new ArrayList<>();
        ActionRepository.findAll().forEach(e -> list.add(e));
        return list;
    }

    @Override
    public Action getActionById(Long ActionId) {
        Action Action = ActionRepository.findById(ActionId).get();
        return Action;
    }

    @Override
    public Action addAction(Action Action) {
        return ActionRepository.save(Action);
    }

    @Override
    public void updateAction(Action Action) {
        ActionRepository.save(Action);
    }

    @Override
    public void deleteAction(Long ActionId) {
        ActionRepository.delete(getActionById(ActionId));
    }

    @Override
    public Collection<Risque> getListRisqueByAction(Long id) {

        Action action = ActionRepository.findById(id).get();
        return action.getRisques();
    }
}
