package ma.gfi.leap.api.LEAPAPI.core.services;

import ma.gfi.leap.api.LEAPAPI.core.dao.models.*;

import java.util.Collection;

public interface IProjetService {

    Collection<Projet> getAllProjets();
    Projet getProjetById(Long ProjetId);
    Projet addProjet(Projet Projet);
    void updateProjet(Projet Projet);
    void deleteProjet(Long ProjetId);
    
    Collection<AttributProgramme> getListAttributProgrammeByProjet(Long id);
    Collection<AttributProjet> getListAttributProjetByProjet(Long id);

    Collection<Action> getListActionByProjet(Long id);
    Collection<Risque> getListRisqueByProjet(Long id);
    Collection<RevisionProjet> getListRevisionByProjet(Long id);





}
