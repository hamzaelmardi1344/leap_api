package ma.gfi.leap.api.LEAPAPI.core.services;


import ma.gfi.leap.api.LEAPAPI.core.dao.models.*;
import ma.gfi.leap.api.LEAPAPI.core.dao.repositories.ProjetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;

@Service
public class ProjetService implements IProjetService {

    @Autowired
    private ProjetRepository ProjetRepository;

    @Override
    public Collection<Projet> getAllProjets() {
        Collection<Projet> list = new ArrayList<>();
        ProjetRepository.findAll().forEach(e -> list.add(e));
        return list;
    }

    @Override
    public Projet getProjetById(Long ProjetId) {
        Projet Projet = ProjetRepository.findById(ProjetId).get();
        return Projet;
    }

    @Override
    public Projet addProjet(Projet Projet) {
        return ProjetRepository.save(Projet);
    }

    @Override
    public void updateProjet(Projet Projet) {
        ProjetRepository.save(Projet);
    }

    @Override
    public void deleteProjet(Long ProjetId) {
        ProjetRepository.delete(getProjetById(ProjetId));
    }

    @Override
    public Collection<AttributProgramme> getListAttributProgrammeByProjet(Long id) {

        Projet projet = ProjetRepository.findById(id).get() ;
        return projet.getAttributProgrammes();
    }

    @Override
    public Collection<AttributProjet> getListAttributProjetByProjet(Long id) {
        Projet projet = ProjetRepository.findById(id).get() ;
        return projet.getAttributProjets();
    }

    @Override
    public Collection<Action> getListActionByProjet(Long id) {
        Projet projet = ProjetRepository.findById(id).get() ;
        return projet.getActions();
    }

    @Override
    public Collection<Risque> getListRisqueByProjet(Long id) {
        Projet projet = ProjetRepository.findById(id).get() ;
        return projet.getRisques();
    }

    @Override
    public Collection<RevisionProjet> getListRevisionByProjet(Long id) {
        Projet projet = ProjetRepository.findById(id).get() ;
        return projet.getRevisionProjets();
    }
}
