package ma.gfi.leap.api.LEAPAPI.core.dao.models;


import javax.persistence.*;

@Entity
public class Risque {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private TypeRisque typeRisque;

    @ManyToOne
    private Perimetre perimetre;

    private String risque;

    @ManyToOne
    private Criticite criticite;

    private String actionMitigation;


    @ManyToOne
    private Action action;

    @ManyToOne
    private Programme programme;
    
    @ManyToOne
    private Projet projet;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public TypeRisque getTypeRisque() {
        return typeRisque;
    }

    public void setTypeRisque(TypeRisque typeRisque) {
        this.typeRisque = typeRisque;
    }

    public Perimetre getPerimetre() {
        return perimetre;
    }

    public void setPerimetre(Perimetre perimetre) {
        this.perimetre = perimetre;
    }

    public String getRisque() {
        return risque;
    }

    public void setRisque(String risque) {
        this.risque = risque;
    }

    public Criticite getCriticite() {
        return criticite;
    }

    public void setCriticite(Criticite criticite) {
        this.criticite = criticite;
    }

    public String getActionMitigation() {
        return actionMitigation;
    }

    public void setActionMitigation(String actionMitigation) {
        this.actionMitigation = actionMitigation;
    }

    public Action getAction() {
        return action;
    }

    public void setAction(Action action) {
        this.action = action;
    }

    public Programme getProgramme() {
        return programme;
    }

    public void setProgramme(Programme programme) {
        this.programme = programme;
    }

    public Projet getProjet() {
        return projet;
    }

    public void setProjet(Projet projet) {
        this.projet = projet;
    }
}
