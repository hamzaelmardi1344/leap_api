package ma.gfi.leap.api.LEAPAPI.core.services;

import ma.gfi.leap.api.LEAPAPI.core.dao.models.Action;
import ma.gfi.leap.api.LEAPAPI.core.dao.models.Risque;

import java.util.Collection;

public interface IActionService {

    Collection<Action> getAllActions();
    Action getActionById(Long ActionId);
    Action addAction(Action Action);
    void updateAction(Action Action);
    void deleteAction(Long ActionId);

    Collection<Risque> getListRisqueByAction(Long id);
}
