package ma.gfi.leap.api.LEAPAPI.core.dao.models;


import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Collection;

@Entity
public class Niveau2 {

     @Id
     @GeneratedValue(strategy = GenerationType.IDENTITY)
     private Long id;

     private String label;

     private String code;

     @ManyToOne
     private Niveau1 niveau1;

     @OneToMany(mappedBy = "niveau2",cascade = CascadeType.ALL)
     @JsonIgnore
     private Collection<Niveau3> niveau3s;

     @OneToMany(mappedBy = "niveau2",cascade = CascadeType.ALL)
     @JsonIgnore
     private Collection<Documentaire> documentaires;

     private Long parentId;

     public Long getId() {
          return id;
     }

     public void setId(Long id) {
          this.id = id;
     }

     public String getLabel() {
          return label;
     }

     public void setLabel(String label) {
          this.label = label;
     }

     public String getCode() {
          return code;
     }

     public void setCode(String code) {
          this.code = code;
     }

     public Niveau1 getNiveau1() {
          return niveau1;
     }

     public void setNiveau1(Niveau1 niveau1) {
          this.niveau1 = niveau1;
     }

     public Collection<Niveau3> getNiveau3s() {
          return niveau3s;
     }

     public void setNiveau3s(Collection<Niveau3> niveau3s) {
          this.niveau3s = niveau3s;
     }

     public Collection<Documentaire> getDocumentaires() {
          return documentaires;
     }

     public void setDocumentaires(Collection<Documentaire> documentaires) {
          this.documentaires = documentaires;
     }

     public Long getParentId() {
          return parentId;
     }

     public void setParentId(Long parentId) {
          this.parentId = parentId;
     }
}
