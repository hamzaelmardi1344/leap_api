package ma.gfi.leap.api.LEAPAPI.core.services;


import ma.gfi.leap.api.LEAPAPI.core.dao.models.Niveau3;
import ma.gfi.leap.api.LEAPAPI.core.dao.repositories.Niveau3Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;

@Service
public class Niveau3Service implements INiveau3Service {

    @Autowired
    private Niveau3Repository Niveau3Repository;

    @Override
    public Collection<Niveau3> getAllNiveau3s() {
        Collection<Niveau3> list = new ArrayList<>();
        Niveau3Repository.findAll().forEach(e -> list.add(e));
        return list;
    }

    @Override
    public Niveau3 getNiveau3ById(Long Niveau3Id) {
        Niveau3 Niveau3 = Niveau3Repository.findById(Niveau3Id).get();
        return Niveau3;
    }

    @Override
    public Niveau3 addNiveau3(Niveau3 Niveau3) {
        return Niveau3Repository.save(Niveau3);
    }

    @Override
    public void updateNiveau3(Niveau3 Niveau3) {
        Niveau3Repository.save(Niveau3);
    }

    @Override
    public void deleteNiveau3(Long Niveau3Id) {
        Niveau3Repository.delete(getNiveau3ById(Niveau3Id));
    }
}
