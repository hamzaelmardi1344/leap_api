package ma.gfi.leap.api.LEAPAPI.core.services;


import ma.gfi.leap.api.LEAPAPI.core.dao.models.DataDoc;
import ma.gfi.leap.api.LEAPAPI.core.dao.repositories.DataDocRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;

@Service
public class DataDocService implements IDataDocService {

    @Autowired
    private DataDocRepository DataDocRepository;

    @Override
    public Collection<DataDoc> getAllDataDocs() {
        Collection<DataDoc> list = new ArrayList<>();
        DataDocRepository.findAll().forEach(e -> list.add(e));
        return list;
    }

    @Override
    public DataDoc getDataDocById(Long DataDocId) {
        DataDoc DataDoc = DataDocRepository.findById(DataDocId).get();
        return DataDoc;
    }

    @Override
    public DataDoc addDataDoc(DataDoc DataDoc) {
        return DataDocRepository.save(DataDoc);
    }

    @Override
    public void updateDataDoc(DataDoc DataDoc) {
        DataDocRepository.save(DataDoc);
    }

    @Override
    public void deleteDataDoc(Long DataDocId) {
        DataDocRepository.delete(getDataDocById(DataDocId));
    }
}
