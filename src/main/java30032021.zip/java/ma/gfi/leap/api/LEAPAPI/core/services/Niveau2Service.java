package ma.gfi.leap.api.LEAPAPI.core.services;


import ma.gfi.leap.api.LEAPAPI.core.dao.models.Niveau2;
import ma.gfi.leap.api.LEAPAPI.core.dao.models.Niveau3;
import ma.gfi.leap.api.LEAPAPI.core.dao.repositories.Niveau2Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;

@Service
public class Niveau2Service implements INiveau2Service {

    @Autowired
    private Niveau2Repository Niveau2Repository;

    @Override
    public Collection<Niveau2> getAllNiveau2s() {
        Collection<Niveau2> list = new ArrayList<>();
        Niveau2Repository.findAll().forEach(e -> list.add(e));
        return list;
    }

    @Override
    public Niveau2 getNiveau2ById(Long Niveau2Id) {
        Niveau2 Niveau2 = Niveau2Repository.findById(Niveau2Id).get();
        return Niveau2;
    }

    @Override
    public Niveau2 addNiveau2(Niveau2 Niveau2) {

        return Niveau2Repository.save(Niveau2);
    }

    @Override
    public void updateNiveau2(Niveau2 Niveau2) {
        Niveau2Repository.save(Niveau2);
    }

    @Override
    public void deleteNiveau2(Long Niveau2Id) {
        Niveau2Repository.delete(getNiveau2ById(Niveau2Id));
    }

    @Override
    public Collection<Niveau3> getListNiveau3ByNiveau2Id(Long id) {
        Niveau2 niveau2 = Niveau2Repository.findById(id).get();
        return niveau2.getNiveau3s();
    }
}
