package ma.gfi.leap.api.LEAPAPI.controllers;



import ma.gfi.leap.api.LEAPAPI.core.dao.models.Niveau1;
import ma.gfi.leap.api.LEAPAPI.core.dao.models.Niveau2;
import ma.gfi.leap.api.LEAPAPI.core.dao.models.Niveau3;
import ma.gfi.leap.api.LEAPAPI.core.services.INiveau2Service;
import ma.gfi.leap.api.LEAPAPI.core.services.INiveau3Service;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import javax.validation.Valid;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collection;

@RestController
@RequestMapping("api")
@CrossOrigin("*")
public class Niveau3Controller {

    @Autowired
    private INiveau3Service Niveau3Service;

    @Autowired
    private INiveau2Service niveau2Service;



    //Fetches Niveau3 by id
    @GetMapping(value= "/niveau3/get/{id}", produces= { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Niveau3> getNiveau3ById(@PathVariable("id") Long id) {
        Niveau3 ob = new Niveau3();
        BeanUtils.copyProperties(Niveau3Service.getNiveau3ById(id), ob);
        return new ResponseEntity<Niveau3>(ob, HttpStatus.OK);
    }



    //Fetches all Niveau3s
    @GetMapping(value= "/niveau3/listNiveau3", produces= { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Collection<Niveau3>> getAllNiveau3s() {
        Collection<Niveau3> Niveau3List = Niveau3Service.getAllNiveau3s();

        return new ResponseEntity<>(Niveau3List, HttpStatus.OK);
    }

    //Creates a new Niveau3
    @PostMapping(value= "/niveau3/creation/{id}", produces= { MediaType.APPLICATION_JSON_VALUE })
    public Niveau3 addNiveau3(@RequestBody Niveau3 Niveau3, UriComponentsBuilder builder,@PathVariable(name = "id")Long id) {
        try {

            Niveau2 niveau2 = niveau2Service.getNiveau2ById(id);
            Path path = null;

            if(niveau2.getNiveau1().getLabel() != null)
            {
                 path = Paths.get(System.getProperty("user.home")+"\\"+niveau2.getNiveau1().getLabel()+"\\"+niveau2.getLabel()+"\\"+Niveau3.getLabel());
            }

            else
            {
                path = Paths.get(System.getProperty("user.home")+"\\"+niveau2.getLabel()+"\\"+Niveau3.getLabel());
            }


            Files.createDirectories(path);

            System.out.println("Directory is created!");
            System.err.println(path);

            //Files.createDirectory(path);

        } catch (IOException e) {
            System.err.println("Failed to create directory!" + e.getMessage());
        }
        Niveau3 Niveau33 = Niveau3Service.addNiveau3(Niveau3);
        //  HttpHeaders headers = new HttpHeaders();
        //  headers.setLocation(builder.path("/Niveau3/{id}").buildAndExpand(Niveau33.getId()).toUri());
        return Niveau33;
    }

    @PutMapping("/niveau3/edit/{id}")
    public void updateNiveau3(@PathVariable(value = "id") Long id,
                              @Valid @RequestBody Niveau3 Niveau3Details) throws Exception{


        try {

            Niveau3 Niveau3 = Niveau3Service.getNiveau3ById(id);
            Path sourcePath = null;
            Path targetPath = null;
            System.err.println(Niveau3.getNiveau2().getNiveau1().getLabel());
            System.err.println(Niveau3Details.getNiveau2().getNiveau1().getLabel());

            if(Niveau3.getNiveau2().getNiveau1().getLabel() != null)
            {
                 sourcePath = Paths.get(System.getProperty("user.home")+"\\"+Niveau3.getNiveau2().getNiveau1().getLabel()+"\\"+Niveau3.getNiveau2().getLabel()+"\\"+Niveau3.getLabel());
                Niveau3.setLabel(Niveau3Details.getLabel());
                Niveau3.setCode(Niveau3Details.getCode());
                Niveau3.setNiveau2(Niveau3Details.getNiveau2());
            }
            else
            {
                 sourcePath = Paths.get(System.getProperty("user.home")+"\\"+Niveau3.getNiveau2().getLabel()+"\\"+Niveau3.getLabel());
                Niveau3.setLabel(Niveau3Details.getLabel());
                Niveau3.setCode(Niveau3Details.getCode());
                Niveau3.setNiveau2(Niveau3Details.getNiveau2());
            }




            if(Niveau3Details.getNiveau2().getNiveau1().getLabel()!= null)
            {
                 targetPath = Paths.get(System.getProperty("user.home")+"\\"+Niveau3Details.getNiveau2().getNiveau1().getLabel()+"\\"+Niveau3Details.getNiveau2().getLabel()+"\\"+Niveau3Details.getLabel());
            }
            else
            {
                 targetPath = Paths.get(System.getProperty("user.home")+"\\"+Niveau3Details.getNiveau2().getLabel()+"\\"+Niveau3Details.getLabel());
            }

            Files.move(sourcePath,targetPath);
            System.out.println("Directory updated!");
            Niveau3Service.updateNiveau3(Niveau3);
            System.err.println(Niveau3.getLabel());
            System.err.println(Niveau3.getNiveau2().getLabel());

            System.err.println(sourcePath);

            System.err.println(targetPath);


            //Files.createDirectory(path);



        } catch (IOException e) {
            System.err.println("Failed to update directory!" + e.getMessage());
        }

    }

    //Deletes evenemnt by id
    @DeleteMapping(value= "/niveau3/delete/{id}", produces= { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Void> deleteNiveau3(@PathVariable("id") Long id) {
        Niveau3Service.deleteNiveau3(id);
        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }

    


 


}
