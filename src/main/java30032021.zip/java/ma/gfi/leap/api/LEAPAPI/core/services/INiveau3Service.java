package ma.gfi.leap.api.LEAPAPI.core.services;

import ma.gfi.leap.api.LEAPAPI.core.dao.models.Niveau3;

import java.util.Collection;

public interface INiveau3Service {

    Collection<Niveau3> getAllNiveau3s();
    Niveau3 getNiveau3ById(Long Niveau3Id);
    Niveau3 addNiveau3(Niveau3 Niveau3);
    void updateNiveau3(Niveau3 Niveau3);
    void deleteNiveau3(Long Niveau3Id);
}
