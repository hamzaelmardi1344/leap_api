package ma.gfi.leap.api.LEAPAPI.core.dao.models;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Collection;

@Entity
@Table(name = "documentaire_v4")
public class Documentaire {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;


    private String nom;



    @OneToMany(mappedBy = "documentaire",cascade = CascadeType.ALL)
    @JsonIgnore
    private Collection<FichierJoint> fichierJoints;



    private String cheminDocument;

    @ManyToOne
    private Niveau1 niveau1;

    @ManyToOne
    private Niveau2 niveau2;

    @ManyToOne
    private Niveau3 niveau3;



    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }


    public Collection<FichierJoint> getFichierJoints() {
        return fichierJoints;
    }

    public void setFichierJoints(Collection<FichierJoint> fichierJoints) {
        this.fichierJoints = fichierJoints;
    }


    public String getCheminDocument() {
        return cheminDocument;
    }

    public void setCheminDocument(String cheminDocument) {
        this.cheminDocument = cheminDocument;
    }

    public Niveau1 getNiveau1() {
        return niveau1;
    }

    public void setNiveau1(Niveau1 niveau1) {
        this.niveau1 = niveau1;
    }

    public Niveau2 getNiveau2() {
        return niveau2;
    }

    public void setNiveau2(Niveau2 niveau2) {
        this.niveau2 = niveau2;
    }

    public Niveau3 getNiveau3() {
        return niveau3;
    }

    public void setNiveau3(Niveau3 niveau3) {
        this.niveau3 = niveau3;
    }



}
