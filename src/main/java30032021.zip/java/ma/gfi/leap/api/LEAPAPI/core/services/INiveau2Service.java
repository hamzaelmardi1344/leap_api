package ma.gfi.leap.api.LEAPAPI.core.services;

import ma.gfi.leap.api.LEAPAPI.core.dao.models.Niveau2;
import ma.gfi.leap.api.LEAPAPI.core.dao.models.Niveau3;

import java.util.Collection;

public interface INiveau2Service {

    Collection<Niveau2> getAllNiveau2s();
    Niveau2 getNiveau2ById(Long Niveau2Id);
    Niveau2 addNiveau2(Niveau2 Niveau2);
    void updateNiveau2(Niveau2 Niveau2);
    void deleteNiveau2(Long Niveau2Id);
    Collection<Niveau3> getListNiveau3ByNiveau2Id(Long id);
}
