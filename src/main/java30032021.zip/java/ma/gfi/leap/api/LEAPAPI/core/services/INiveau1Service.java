package ma.gfi.leap.api.LEAPAPI.core.services;

import ma.gfi.leap.api.LEAPAPI.core.dao.models.Niveau1;
import ma.gfi.leap.api.LEAPAPI.core.dao.models.Niveau2;

import java.util.Collection;

public interface INiveau1Service {

    Collection<Niveau1> getAllNiveau1s();
    Niveau1 getNiveau1ById(Long Niveau1Id);
    Niveau1 addNiveau1(Niveau1 Niveau1);
    void updateNiveau1(Niveau1 Niveau1);
    void deleteNiveau1(Long Niveau1Id);
    Collection<Niveau2> getListNiveau2ByNiveau1(Long id);
    Collection<Niveau1> getListNiveau1ExpectDefaultValue();
}
