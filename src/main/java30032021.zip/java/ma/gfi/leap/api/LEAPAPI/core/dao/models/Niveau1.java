package ma.gfi.leap.api.LEAPAPI.core.dao.models;


import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Collection;

@Entity
public class Niveau1 {

     @Id
     @GeneratedValue(strategy = GenerationType.IDENTITY)
     private Long id;

     private String label;

     private String code;

     private Long parentId;

     private Boolean showChildren;

     @OneToMany(mappedBy = "niveau1",cascade = CascadeType.ALL)
    @JsonIgnore
    private Collection<Niveau2> niveau2s;

    @OneToMany(mappedBy = "niveau1",cascade = CascadeType.ALL)
    @JsonIgnore
    private Collection<Documentaire> documentaires;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Collection<Niveau2> getNiveau2s() {
        return niveau2s;
    }

    public void setNiveau2s(Collection<Niveau2> niveau2s) {
        this.niveau2s = niveau2s;
    }

    public Collection<Documentaire> getDocumentaires() {
        return documentaires;
    }

    public void setDocumentaires(Collection<Documentaire> documentaires) {
        this.documentaires = documentaires;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public Boolean getShowChildren() {
        return showChildren;
    }

    public void setShowChildren(Boolean showChildren) {
        this.showChildren = showChildren;
    }
}
