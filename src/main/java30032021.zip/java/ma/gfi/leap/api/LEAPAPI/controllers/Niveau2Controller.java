package ma.gfi.leap.api.LEAPAPI.controllers;



import ma.gfi.leap.api.LEAPAPI.core.dao.models.Niveau1;
import ma.gfi.leap.api.LEAPAPI.core.dao.models.Niveau2;
import ma.gfi.leap.api.LEAPAPI.core.dao.models.Niveau3;
import ma.gfi.leap.api.LEAPAPI.core.services.INiveau1Service;
import ma.gfi.leap.api.LEAPAPI.core.services.INiveau2Service;
import ma.gfi.leap.api.LEAPAPI.core.services.Niveau3Service;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import javax.validation.Valid;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collection;

@RestController
@RequestMapping("api")
@CrossOrigin("*")
public class Niveau2Controller {

    @Autowired
    private INiveau2Service Niveau2Service;


    @Autowired
    private INiveau1Service niveau1Service;

    //Fetches Niveau2 by id
    @GetMapping(value= "/niveau2/get/{id}", produces= { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Niveau2> getNiveau2ById(@PathVariable("id") Long id) {
        Niveau2 ob = new Niveau2();
        BeanUtils.copyProperties(Niveau2Service.getNiveau2ById(id), ob);
        return new ResponseEntity<Niveau2>(ob, HttpStatus.OK);
    }



    //Fetches all Niveau2s
    @GetMapping(value= "/niveau2/listNiveau2", produces= { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Collection<Niveau2>> getAllNiveau2s() {
        Collection<Niveau2> Niveau2List = Niveau2Service.getAllNiveau2s();

        return new ResponseEntity<>(Niveau2List, HttpStatus.OK);
    }

    //Creates a new Niveau2
    @PostMapping(value= "/niveau2/creation/{id}", produces= { MediaType.APPLICATION_JSON_VALUE })
    public Niveau2 addNiveau2(@RequestBody Niveau2 Niveau2, UriComponentsBuilder builder,@PathVariable(name = "id") Long id) {
        try {

            Niveau1 niveau1 = niveau1Service.getNiveau1ById(id);

            Path path = Paths.get(System.getProperty("user.home")+"\\"+niveau1.getLabel()+"\\"+Niveau2.getLabel());

            Files.createDirectories(path);

            System.out.println("Directory is created!");

            //Files.createDirectory(path);

        } catch (IOException e) {
            System.err.println("Failed to create directory!" + e.getMessage());
        }
        Niveau2 Niveau22 = Niveau2Service.addNiveau2(Niveau2);
        //  HttpHeaders headers = new HttpHeaders();
        //  headers.setLocation(builder.path("/Niveau2/{id}").buildAndExpand(Niveau22.getId()).toUri());
        return Niveau22;
    }


   //Updates evenmement
    @PutMapping("/niveau2/edit/{id}")
    public void updateNiveau2(@PathVariable(value = "id") Long Niveau2Id,
                                                 @Valid @RequestBody Niveau2 Niveau2Details) throws Exception{


        try {

            Niveau2 Niveau2 = Niveau2Service.getNiveau2ById(Niveau2Id);


            Path sourcePath = Paths.get(System.getProperty("user.home")+"\\"+Niveau2.getNiveau1().getLabel()+"\\"+Niveau2.getLabel());
            Niveau2.setLabel(Niveau2Details.getLabel());
            Niveau2.setCode(Niveau2Details.getCode());
            Niveau2.setNiveau1(Niveau2Details.getNiveau1());

            Path targetPath = Paths.get(System.getProperty("user.home")+"\\"+Niveau2Details.getNiveau1().getLabel()+"\\"+Niveau2Details.getLabel());
            Files.move(sourcePath,targetPath);
            System.out.println("Directory updated!");
            Niveau2Service.updateNiveau2(Niveau2);
            System.err.println(Niveau2.getLabel());
            System.err.println(Niveau2.getNiveau1().getLabel());


            //Files.createDirectory(path);



        } catch (IOException e) {
            System.err.println("Failed to update directory!" + e.getMessage());
        }

    }

    //Deletes evenemnt by id
    @DeleteMapping(value= "/niveau2/delete/{id}", produces= { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Void> deleteNiveau2(@PathVariable("id") Long id) {
        Niveau2Service.deleteNiveau2(id);
        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }




    @GetMapping(value = "/niveau2/{id}/niveau3s")
    public ResponseEntity<Collection<Niveau3>> getListNiveau2ByNiveau1(@PathVariable("id") Long id)
    {
        Collection<Niveau3> niveau3s = Niveau2Service.getListNiveau3ByNiveau2Id(id);
        return  new ResponseEntity<Collection<Niveau3>>(niveau3s,HttpStatus.OK);
    }



}
