package ma.gfi.leap.api.LEAPAPI.controllers;



import ma.gfi.leap.api.LEAPAPI.core.dao.models.FichierJoint;
import ma.gfi.leap.api.LEAPAPI.core.dao.models.Niveau1;
import ma.gfi.leap.api.LEAPAPI.core.dao.models.Niveau2;
import ma.gfi.leap.api.LEAPAPI.core.services.INiveau1Service;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import javax.validation.Valid;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collection;

@RestController
@RequestMapping("api")
@CrossOrigin("*")
public class Niveau1Controller {

    @Autowired
    private INiveau1Service Niveau1Service;



    //Fetches Niveau1 by id
    @GetMapping(value= "/niveau1/get/{id}", produces= { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Niveau1> getNiveau1ById(@PathVariable("id") Long id) {
        Niveau1 ob = new Niveau1();
        BeanUtils.copyProperties(Niveau1Service.getNiveau1ById(id), ob);
        return new ResponseEntity<Niveau1>(ob, HttpStatus.OK);
    }



    //Fetches all Niveau1s
    @GetMapping(value= "/niveau1/listNiveau1", produces= { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Collection<Niveau1>> getAllNiveau1s() {
        Collection<Niveau1> Niveau1List = Niveau1Service.getAllNiveau1s();

        return new ResponseEntity<>(Niveau1List, HttpStatus.OK);
    }

    //Fetches all Niveau1s
    @GetMapping(value= "/niveau1/listNiveau1ExceptDefault", produces= { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Collection<Niveau1>> getListNiveau1ExceptDefault() {
        Collection<Niveau1> Niveau1List = Niveau1Service.getListNiveau1ExpectDefaultValue();

        return new ResponseEntity<>(Niveau1List, HttpStatus.OK);
    }

    //Creates a new Niveau1
    @PostMapping(value= "/niveau1/creation", produces= { MediaType.APPLICATION_JSON_VALUE })
    public Niveau1 addNiveau1(@RequestBody Niveau1 Niveau1, UriComponentsBuilder builder) {
        Niveau1 Niveau11 = Niveau1Service.addNiveau1(Niveau1);
        //  HttpHeaders headers = new HttpHeaders();
        //  headers.setLocation(builder.path("/Niveau1/{id}").buildAndExpand(Niveau11.getId()).toUri());
        return Niveau11;
    }


    //Updates evenmement
    @PutMapping("/niveau1/edit/{id}")
    public void updateNiveau1(@PathVariable(value = "id") Long Niveau1Id,
                                                 @Valid @RequestBody Niveau1 Niveau1Details) throws Exception{
        Niveau1 Niveau1 = Niveau1Service.getNiveau1ById(Niveau1Id);

        try {

            Path sourcePath = Paths.get(System.getProperty("user.home")+"\\"+Niveau1.getLabel());
            Niveau1.setLabel(Niveau1Details.getLabel());
            Niveau1.setCode(Niveau1Details.getCode());
            Path targetPath = Paths.get(System.getProperty("user.home")+"\\"+Niveau1Details.getLabel());
            Files.move(sourcePath,targetPath);
            System.out.println("Directory updated!");
            Niveau1Service.updateNiveau1(Niveau1);

            //Files.createDirectory(path);



        } catch (IOException e) {
            System.err.println("Failed to update directory!" + e.getMessage());
        }

    }

    //Deletes evenemnt by id
    @DeleteMapping(value= "/niveau1/delete/{id}", produces= { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Void> deleteNiveau1(@PathVariable("id") Long id) {
        Niveau1Service.deleteNiveau1(id);
        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }


    @GetMapping(value = "/niveau1/{id}/niveau2s")
    public ResponseEntity<Collection<Niveau2>> getListNiveau2ByNiveau1(@PathVariable("id") Long id)
    {
        Collection<Niveau2> niveau2s = Niveau1Service.getListNiveau2ByNiveau1(id);
        return  new ResponseEntity<Collection<Niveau2>>(niveau2s,HttpStatus.OK);
    }









}
