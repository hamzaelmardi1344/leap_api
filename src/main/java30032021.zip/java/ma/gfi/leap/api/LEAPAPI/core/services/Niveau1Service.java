package ma.gfi.leap.api.LEAPAPI.core.services;


import ma.gfi.leap.api.LEAPAPI.core.dao.models.Niveau1;
import ma.gfi.leap.api.LEAPAPI.core.dao.models.Niveau2;
import ma.gfi.leap.api.LEAPAPI.core.dao.repositories.Niveau1Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.stream.Collectors;

@Service
public class Niveau1Service implements INiveau1Service {

    @Autowired
    private Niveau1Repository Niveau1Repository;

    @Override
    public Collection<Niveau1> getAllNiveau1s() {
        Collection<Niveau1> list = new ArrayList<>();
        Niveau1Repository.findAll().forEach(e -> list.add(e));
        return list;
    }

    @Override
    public Niveau1 getNiveau1ById(Long Niveau1Id) {
        Niveau1 Niveau1 = Niveau1Repository.findById(Niveau1Id).get();
        return Niveau1;
    }

    @Override
    public Niveau1 addNiveau1(Niveau1 Niveau1) {


        try {

            Path path = Paths.get(System.getProperty("user.home")+"\\"+Niveau1.getLabel());

            Files.createDirectories(path);

            System.out.println("Directory is created!");

            //Files.createDirectory(path);

        } catch (IOException e) {
            System.err.println("Failed to create directory!" + e.getMessage());
        }
        return Niveau1Repository.save(Niveau1);
    }

    @Override
    public void updateNiveau1(Niveau1 Niveau1) {
        Niveau1Repository.save(Niveau1);
    }

    @Override
    public void deleteNiveau1(Long Niveau1Id) {
        Niveau1Repository.delete(getNiveau1ById(Niveau1Id));
    }

    @Override
    public Collection<Niveau2> getListNiveau2ByNiveau1(Long id) {
        Niveau1 niveau1 = Niveau1Repository.findById(id).get();
        return niveau1.getNiveau2s();
    }

    @Override
    public Collection<Niveau1> getListNiveau1ExpectDefaultValue() {
        Collection<Niveau1> niveau1s = Niveau1Repository.findAll();

        return niveau1s.stream().filter(a -> !a.getCode().equals("DEF")).collect(Collectors.toList());
    }
}
