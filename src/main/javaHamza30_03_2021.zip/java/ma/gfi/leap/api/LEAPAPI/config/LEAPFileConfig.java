package ma.gfi.leap.api.LEAPAPI.config;

public class LEAPFileConfig {
    public static String PATH_PROJET = System.getProperty("user.home")+"/uploadedFile/projetLeap/";
    public static String PATH_PROGRAMME = System.getProperty("user.home")+"/uploadedFile/programmeLeap/";
    public static String PATH_ACTION = System.getProperty("user.home")+"/uploadedFile/actionLeap/";
    public static String PATH_DOCUMENTAIRE = System.getProperty("user.home")+"/uploadedFile/documentaireLeap/";
    public static String PATH_DEFAULT = System.getProperty("user.home")+"/uploadedFile/";

/*
    public static String PATH_SUIVI_LIVRAISON = "/mnt/nfsfileshare/KhabeerFiles/SuiviLivraison/";
    public static String PATH_REF_VISITEUR = "/mnt/nfsfileshare/KhabeerFiles/AccueilSecurite/RefVisiteur/";
    public static String PATH_REF_EVENT_GEN = "/mnt/nfsfileshare/KhabeerFiles/Evenement/General/";
    public static String PATH_REF_EVENT_DAFSIL = "/mnt/nfsfileshare/KhabeerFiles/Evenement/DAFSIL/";
    public static String PATH_REF_EVENT_DP = "/mnt/nfsfileshare/KhabeerFiles/Evenement/DP/";
    public static String PATH_REF_EVENT_DDP = "/mnt/nfsfileshare/KhabeerFiles/Evenement/DDP/";
    public static String PATH_REF_EVENT_DEFAULT = "/mnt/nfsfileshare/KhabeerFiles/Evenement/";
    public static String PATH_REF_EVENT_RESTAU = "/mnt/nfsfileshare/KhabeerFiles/Evenement/Restauration/";
    public static String PATH_REF_EVENT_JOURNALISTE = "/mnt/nfsfileshare/KhabeerFiles/Evenement/Journaliste/";
    public static String PATH_REF_EVENT_MEMBREDEL = "/mnt/nfsfileshare/KhabeerFiles/Evenement/Membre_Delegation/";
    public static String PATH_REF_DDE_ROAMING = "/mnt/nfsfileshare/KhabeerFiles/Flotte/Demande_Roaming/";*/
}
