package ma.gfi.leap.api.LEAPAPI.core.services;

import ma.gfi.leap.api.LEAPAPI.core.dao.models.Documentaire;
import ma.gfi.leap.api.LEAPAPI.core.dao.models.FichierJoint;

import java.util.Collection;

public interface IDocumentaireService {

    Collection<Documentaire> getAllDocumentaires();
    Documentaire getDocumentaireById(Long DocumentaireId);
    Documentaire addDocumentaire(Documentaire Documentaire);
    void updateDocumentaire(Documentaire Documentaire);
    void deleteDocumentaire(Long DocumentaireId);
    Collection<FichierJoint> getFileByDocumentID(Long id);
    Collection<Documentaire> getChildrenByDocId(Long id);
}
