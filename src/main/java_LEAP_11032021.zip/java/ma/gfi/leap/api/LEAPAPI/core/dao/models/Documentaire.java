package ma.gfi.leap.api.LEAPAPI.core.dao.models;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Collection;

@Entity
@Table(name = "documentaire_v1")
public class Documentaire {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;


    @ManyToOne
    public DataDoc data;

    @ManyToOne
    private Categorie categorie;

    @OneToMany(mappedBy = "documentaire",cascade = CascadeType.ALL)
    @JsonIgnore
    private Collection<FichierJoint> fichierJoints;

    @ManyToOne
    private Documentaire documentaireParent;

    @OneToMany(mappedBy = "documentaireParent",cascade = CascadeType.ALL)
    @JsonIgnore
    private Collection<Documentaire> children;


    private String cheminDocument;



    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public DataDoc getData() {
        return data;
    }

    public void setData(DataDoc data) {
        this.data = data;
    }

    public Categorie getCategorie() {
        return categorie;
    }

    public void setCategorie(Categorie categorie) {
        this.categorie = categorie;
    }

    public Collection<FichierJoint> getFichierJoints() {
        return fichierJoints;
    }

    public void setFichierJoints(Collection<FichierJoint> fichierJoints) {
        this.fichierJoints = fichierJoints;
    }

    public Documentaire getDocumentaireParent() {
        return documentaireParent;
    }

    public void setDocumentaireParent(Documentaire documentaireParent) {
        this.documentaireParent = documentaireParent;
    }


    public Collection<Documentaire> getChildren() {
        return children;
    }

    public void setChildren(Collection<Documentaire> children) {
        this.children = children;
    }

    public String getCheminDocument() {
        return cheminDocument;
    }

    public void setCheminDocument(String cheminDocument) {
        this.cheminDocument = cheminDocument;
    }
}
