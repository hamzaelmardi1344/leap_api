package ma.gfi.leap.api.LEAPAPI.core.dao.models;


import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Collection;


@Entity
public class DataDoc {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nom;

    @OneToMany(mappedBy = "data",cascade = CascadeType.ALL)
    @JsonIgnore
    private Collection<Documentaire> documentaires;

    @ManyToOne
    private Documentaire documentaire;

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Collection<Documentaire> getDocumentaires() {
        return documentaires;
    }

    public void setDocumentaires(Collection<Documentaire> documentaires) {
        this.documentaires = documentaires;
    }

    public Documentaire getDocumentaire() {
        return documentaire;
    }

    public void setDocumentaire(Documentaire documentaire) {
        this.documentaire = documentaire;
    }
}
