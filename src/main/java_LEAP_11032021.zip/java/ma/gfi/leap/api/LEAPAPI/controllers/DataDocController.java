package ma.gfi.leap.api.LEAPAPI.controllers;



import ma.gfi.leap.api.LEAPAPI.core.dao.models.DataDoc;
import ma.gfi.leap.api.LEAPAPI.core.services.IDataDocService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Collection;

@RestController
@RequestMapping("api")
@CrossOrigin("*")
public class DataDocController {

    @Autowired
    private IDataDocService DataDocService;



    //Fetches DataDoc by id
    @GetMapping(value= "/dataDoc/get/{id}", produces= { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<DataDoc> getDataDocById(@PathVariable("id") Long id) {
        DataDoc ob = new DataDoc();
        BeanUtils.copyProperties(DataDocService.getDataDocById(id), ob);
        return new ResponseEntity<DataDoc>(ob, HttpStatus.OK);
    }



    //Fetches all DataDocs
    @GetMapping(value= "/dataDoc/listDataDoc", produces= { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Collection<DataDoc>> getAllDataDocs() {
        Collection<DataDoc> DataDocList = DataDocService.getAllDataDocs();

        return new ResponseEntity<>(DataDocList, HttpStatus.OK);
    }

    //Creates a new DataDoc
    @PostMapping(value= "/dataDoc/creation", produces= { MediaType.APPLICATION_JSON_VALUE })
    public DataDoc addDataDoc(@RequestBody DataDoc DataDoc, UriComponentsBuilder builder) {
        DataDoc DataDoc1 = DataDocService.addDataDoc(DataDoc);
        //  HttpHeaders headers = new HttpHeaders();
        //  headers.setLocation(builder.path("/DataDoc/{id}").buildAndExpand(DataDoc1.getId()).toUri());
        return DataDoc1;
    }


  /*  //Updates evenmement
    @PutMapping("/DataDoc/edit/{id}")
    public ResponseEntity<DataDoc> updateDataDoc(@PathVariable(value = "id") Long DataDocId,
                                                 @Valid @RequestBody DataDoc DataDocDetails) throws Exception{
        DataDoc DataDoc = DataDocService.getDataDocById(DataDocId);

        DataDoc.setValeur(DataDocDetails.getValeur());


        final DataDoc updatedDataDoc = DataDocService.addDataDoc(DataDoc);
        return ResponseEntity.ok(updatedDataDoc);
    }
*/
    //Deletes evenemnt by id
    @DeleteMapping(value= "/dataDoc/delete/{id}", produces= { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Void> deleteDataDoc(@PathVariable("id") Long id) {
        DataDocService.deleteDataDoc(id);
        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }

    


 


}
