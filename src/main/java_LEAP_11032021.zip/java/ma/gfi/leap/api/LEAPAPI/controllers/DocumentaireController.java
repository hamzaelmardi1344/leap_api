package ma.gfi.leap.api.LEAPAPI.controllers;



import ma.gfi.leap.api.LEAPAPI.core.dao.models.FichierJoint;
import ma.gfi.leap.api.LEAPAPI.core.dao.models.Documentaire;
import ma.gfi.leap.api.LEAPAPI.core.services.IDocumentaireService;
import net.minidev.json.JSONObject;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import javax.validation.Valid;
import java.io.IOException;
import java.util.Collection;

@RestController
@RequestMapping("api")
@CrossOrigin("*")
public class DocumentaireController {

    @Autowired
    private IDocumentaireService DocumentaireService;



    //Fetches Documentaire by id
    @GetMapping(value= "/documentaire/get/{id}", produces= { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Documentaire> getDocumentaireById(@PathVariable("id") Long id) {
        Documentaire ob = new Documentaire();
        BeanUtils.copyProperties(DocumentaireService.getDocumentaireById(id), ob);
        return new ResponseEntity<Documentaire>(ob, HttpStatus.OK);
    }



    //Fetches all Documentaires
    @GetMapping(value= "/documentaire/listDocumentaire", produces= { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<JSONObject> getAllDocumentaires() {
        Collection<Documentaire> DocumentaireList = DocumentaireService.getAllDocumentaires();

        JSONObject json = new JSONObject();
        json.put("data", DocumentaireList);


        return new ResponseEntity<JSONObject>(json, HttpStatus.OK);
    }

    //Creates a new Documentaire
    @PostMapping(value= "/documentaire/creation", produces= { MediaType.APPLICATION_JSON_VALUE })
    public Documentaire addDocumentaire(@RequestBody Documentaire Documentaire, UriComponentsBuilder builder) {
        Documentaire Documentaire1 = DocumentaireService.addDocumentaire(Documentaire);
        //  HttpHeaders headers = new HttpHeaders();
        //  headers.setLocation(builder.path("/Documentaire/{id}").buildAndExpand(Documentaire1.getId()).toUri());
        return Documentaire1;
    }


    //Updates evenmement
    @PutMapping("/documentaire/edit/{id}")
    public ResponseEntity<Documentaire> updateDocumentaire(@PathVariable(value = "id") Long DocumentaireId,
                                                 @Valid @RequestBody Documentaire DocumentaireDetails) throws Exception{
        Documentaire Documentaire = DocumentaireService.getDocumentaireById(DocumentaireId);

        Documentaire.setData(DocumentaireDetails.getData());
        Documentaire.setDocumentaireParent(DocumentaireDetails.getDocumentaireParent());
        Documentaire.setCategorie(DocumentaireDetails.getCategorie());
        Documentaire.setChildren(DocumentaireDetails.getChildren());



        final Documentaire updatedDocumentaire = DocumentaireService.addDocumentaire(Documentaire);
        return ResponseEntity.ok(updatedDocumentaire);
    }

    //Deletes evenemnt by id
    @DeleteMapping(value= "/documentaire/delete/{id}", produces= { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Void> deleteDocumentaire(@PathVariable("id") Long id) throws IOException {
        //Files.deleteIfExists(Paths.get(KhabeerConfig.PATH_REF_EVENT_GEN +Documentaire.getValeur()));
        DocumentaireService.deleteDocumentaire(id);
        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }



    @GetMapping(value = "/documentaire/{id}/fichierJoints")
    public ResponseEntity<Collection<FichierJoint>> getListFichierJointByProjetID(@PathVariable("id") Long id)
    {
        Collection<FichierJoint> FichierJoints = DocumentaireService.getFileByDocumentID(id);
        return  new ResponseEntity<Collection<FichierJoint>>(FichierJoints,HttpStatus.OK);
    }


    @GetMapping(value = "/documentaire/getChildren/{id}/childrens")
    public ResponseEntity<Collection<Documentaire>> getChildrenByDocId(@PathVariable(name = "id")Long id)
    {
        Collection<Documentaire> documentaires = DocumentaireService.getChildrenByDocId(id);
        return  new ResponseEntity<>(documentaires,HttpStatus.OK);
    }










}
