package ma.gfi.leap.api.LEAPAPI.core.services;


import ma.gfi.leap.api.LEAPAPI.core.dao.models.Documentaire;
import ma.gfi.leap.api.LEAPAPI.core.dao.models.FichierJoint;
import ma.gfi.leap.api.LEAPAPI.core.dao.repositories.DocumentaireRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;

@Service
public class DocumentaireService implements IDocumentaireService {

    @Autowired
    private DocumentaireRepository DocumentaireRepository;

    @Override
    public Collection<Documentaire> getAllDocumentaires() {
        Collection<Documentaire> list = new ArrayList<>();
        DocumentaireRepository.findAll().forEach(e -> list.add(e));
        return list;
    }

    @Override
    public Documentaire getDocumentaireById(Long DocumentaireId) {
        Documentaire Documentaire = DocumentaireRepository.findById(DocumentaireId).get();
        return Documentaire;
    }

    @Override
    public Documentaire addDocumentaire(Documentaire Documentaire) {
        return DocumentaireRepository.save(Documentaire);
    }

    @Override
    public void updateDocumentaire(Documentaire Documentaire) {
        DocumentaireRepository.save(Documentaire);
    }

    @Override
    public void deleteDocumentaire(Long DocumentaireId) {
        DocumentaireRepository.delete(getDocumentaireById(DocumentaireId));
    }

    @Override
    public Collection<FichierJoint> getFileByDocumentID(Long id) {

        Documentaire documentaire = DocumentaireRepository.findById(id).get();
        return documentaire.getFichierJoints();
    }

    @Override
    public Collection<Documentaire> getChildrenByDocId(Long id) {
        Documentaire documentaire = DocumentaireRepository.findById(id).get();
        return documentaire.getChildren();
    }
}
