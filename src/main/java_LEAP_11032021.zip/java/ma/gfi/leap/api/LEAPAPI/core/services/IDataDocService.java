package ma.gfi.leap.api.LEAPAPI.core.services;

import ma.gfi.leap.api.LEAPAPI.core.dao.models.DataDoc;

import java.util.Collection;

public interface IDataDocService {

    Collection<DataDoc> getAllDataDocs();
    DataDoc getDataDocById(Long DataDocId);
    DataDoc addDataDoc(DataDoc DataDoc);
    void updateDataDoc(DataDoc DataDoc);
    void deleteDataDoc(Long DataDocId);
}
